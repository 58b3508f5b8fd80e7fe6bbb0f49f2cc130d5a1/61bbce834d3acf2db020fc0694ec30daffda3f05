<?php    $public='';    if(config('app.env') == 'production')    $public ='public'; ?> 
<?php $__env->startSection('title','Search users'); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-header-search">
        <div class="content-header content-header-fullrow col-sm-10 col-sm-offset-1">
            <form action="<?php echo e(url('/admin/search')); ?>" method="get">
                <div class="input-group">
                    <input class="form-control" placeholder="Enter your search query or hit ESC.."
                           id="page-header-search-input"
                           name="search" type="text" value="<?php echo e(isset($query) ? $query : null); ?>" required>
                    <span class="input-group-btn">
                        <button type="submit" class="btn btn-secondary">
                        <i class="fa fa-search"></i>
                        </button>
                        </span>
                </div>
            </form>
        </div>
    </div>

    <nav class="breadcrumb bg-white push">
        <a class="breadcrumb-item" href="<?php echo e(url('/admin')); ?>">Admin</a>
        <span class="breadcrumb-item active">Search Users</span>
    </nav>
    <div class="block">
        <div id="search">
            <?php echo $__env->make('admin.partials.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        <?php if(Auth::user()->access_level >= 4): ?>
        function verifyTransaction(id, action) {
            var data = {
                'id': id,
                'action': action,
                'search': '<?php echo e(isset($query) ? $query : ''); ?>'
            };
            $.post('/admin/transactions/verify', data, function (result) {
                alert(result.message);
                $('#search').fadeOut(300);
                $('#search').html(result.html);
                $('#search').fadeIn(300);
            }).fail(function () {
                alert('Sorry, an error occurred');
            });
        }
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>