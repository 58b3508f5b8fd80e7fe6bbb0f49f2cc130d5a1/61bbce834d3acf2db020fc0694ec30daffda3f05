<?php if(sizeof($withdrawals)>0): ?>

    <div class="block-title">
        <p style="font-size:1.5em;">Your <strong>Withdrawals</strong></p>
    </div>
    <div class="table-responsive">
        <table id="general-table" class="table table-striped table-vcenter">
            <thead>
            <tr>
                <th class="text-center">S/No.</th>
                <th class="text-center">Withdrawal ID</th>
                <?php if($action == 'pnm'): ?>
                    <th>PNM</th>
                <?php elseif($action == 'ngn'): ?>
                    <th>NGN</th>
                <?php endif; ?>
                <th>From</th>
                <th>To</th>
                <th>Type</th>
                <?php if($action == 'pnm'): ?>
                    <th>Wallet Address</th>
                <?php elseif($action == 'ngn'): ?>
                    <th>Bank Name</th>
                    <th>Acc. Number</th>
                <?php endif; ?>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $i=0; ?>
            <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $i++;
                 if($withdrawal->status=='pending'||$withdrawal->status =='requested')
                    $badge ="badge-warning";
                elseif ($withdrawal->status=='successful')
                    $badge ="badge-success";
                elseif ($withdrawal->status=='failed')
                    $badge ="badge-danger";
                ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td>
                        <a href="javascript:void (0)"><?php echo e($withdrawal->transaction_id); ?></a>
                    </td>
                    <?php if($action == 'pnm'): ?>
                        <td><?php echo e($withdrawal->amount); ?></td>
                    <?php elseif($action == 'ngn'): ?>
                        <td><?php echo e($withdrawal->amount * $withdrawal->value); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($withdrawal->from); ?></td>
                    <td><?php echo e($withdrawal->to); ?></td>
                    <td><?php echo e($withdrawal->type); ?></td>
                    <?php if($action == 'pnm'): ?>
                        <td><?php echo e($withdrawal->wallet_address); ?></td>
                    <?php elseif($action == 'ngn'): ?>
                        <td><?php echo e($withdrawal->bank_name); ?></td>
                        <td><?php echo e($withdrawal->bank_acc_no); ?></td>
                    <?php endif; ?>
                    <td class="text-center">
                        <span class="badge <?php echo e($badge); ?>"><?php echo e($withdrawal->status); ?></span>
                    </td>
                    <td><?php echo e(date('d/m/Y',strtotime($withdrawal->created_at))); ?></td>
                    <td class="text-center">
                        <div class="btn-group">
                            <?php if($withdrawal->status=='failed' || in_array($withdrawal->status, ['pending','requested']) ): ?>
                                <button data-original-title="approve" type="button"
                                        class="btn btn-sm btn-alt-success"
                                        data-toggle="tooltip"
                                        title="Approve"
                                        onclick="verifyWithdrawal(<?php echo e(($withdrawal->id+1127)); ?>, 'approve')">
                                    <i class="fa fa-check"></i>
                                </button>
                            <?php endif; ?>
                            <?php if($withdrawal->status=='successful' || in_array($withdrawal->status, ['pending','requested'])): ?>
                                <button data-original-title="Revoke" type="button"
                                        class="btn btn-sm btn-alt-danger"
                                        data-toggle="tooltip"
                                        title="Revoke" onclick="verifyWithdrawal(<?php echo e(($withdrawal->id+1127)); ?>, 'revoke')">
                                    <i class="fa fa-times"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="block">
        <div class="alert alert-warning">
            <h2>No data to display</h2>
            <p>Sorry, but there are no withdrawals to display from the database.</p>
        </div>
    </div>
<?php endif; ?>