<?php    $public='';    if(config('app.env') == 'production')    $public ='public'; ?> 
<?php $__env->startSection('title', 'Transactions History'); ?>
<?php $__env->startSection('content'); ?>

    <nav class="breadcrumb bg-white push">
        <a class="breadcrumb-item" href="<?php echo e(url('/admin')); ?>">Admin</a>
        <span class="breadcrumb-item active">Transaction History</span>
    </nav>
    <div class="block">
        <div class="block-header block-header-default">
            <h3 class="block-title">Transactions
                <small>History</small>
            </h3>
        </div>
        <?php if(sizeof($transactions)>0): ?>

            <div class="block-title">
                <p style="font-size:1.5em;">Your <strong>Transactions</strong></p>
            </div>
            <div class="table-responsive">
                <table id="general-table" class="table table-striped table-vcenter">
                    <thead>
                    <tr>
                        <th class="text-center">S/No.</th>
                        <th class="text-center">Transaction ID</th>
                        <th>PNM</th>
                        <th>NGN</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php

                            $trans1 = substr($transaction->transaction_id,0,6 );
                            $trans2 = substr($transaction->transaction_id,-6);
                            $to1 = substr($transaction->to,0,6 );
                            $to2 = substr($transaction->to,-6);
                            $from1 = substr($transaction->from,0,6 );
                            $from2 = substr($transaction->from,-6);
                            if($transaction->status=='successful')
                                $status ='success';
                            elseif($transaction->status=='failed')
                                $status ='danger';
                            else
                                $status ='pending';
                        ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>
                                <?php if(strlen($transaction->transaction_id) > 15): ?>
                                    <?php echo e("$trans1......$trans2"); ?>

                                <?php else: ?>
                                    <?php echo e($transaction->transaction_id); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($transaction->amount/100000); ?></td>
                            <td><?php echo e($transaction->amount/100000 * $value); ?></td>
                            <td>
                                <?php if(strlen($transaction->from) > 15): ?>
                                    <?php echo e("$from1......$from2"); ?>

                                <?php else: ?>
                                    <?php echo e($transaction->from); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(strlen($transaction->to) > 15): ?>
                                    <?php echo e("$to1......$to2"); ?>

                                <?php else: ?>
                                    <?php echo e($transaction->to); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($transaction->type); ?></td>
                            <td><span class="badge badge-sm badge-<?php echo e($status); ?>"><?php echo e($transaction->status); ?></span></td>
                            <td><?php echo e(date('d-m-Y',strtotime($transaction->created_at))); ?></td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>
            <div class="block">
                <div class="alert alert-warning">
                    <h2>No data to display</h2>
                    <p>Sorry, but there are no transactions to display from the database.</p>
                </div>
            </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>