<?php    $public='';    if(config('app.env') == 'production')    $public ='public'; ?> 
<?php $__env->startSection('title', strtoupper($action). ' withdrawals'); ?>
<?php $__env->startSection('content'); ?>

    <nav class="breadcrumb bg-white push">
        <a class="breadcrumb-item" href="<?php echo e(url('/admin')); ?>">Admin</a>
        <span class="breadcrumb-item active"></span>
    </nav>
    <div class="block">
        <div class="block-header block-header-default">
            <h3 class="block-title">Withdrawals
                <small><?php echo e(strtoupper($action)); ?></small>
            </h3>
        </div>
        <div id="withdrawals">
            <?php echo $__env->make('admin.partials.withdrawal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function verifyWithdrawal(id, action) {
            var data = {
                'id': id,
                'action': action,
                'type': '<?php echo e($action); ?>',
                'for': '<?php echo e($type); ?>'
            };
            $.post('/admin/transactions/withdrawal', data, function (result) {

                alert(result.message);

                $('#withdrawals').fadeOut(300);
                $('#withdrawals').html(result.html);
                $('#withdrawals').fadeIn(300);
            }).fail(function () {
                alert('Sorry, an error occurred');
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>