<?php $__env->startSection('title', 'Transactions History'); ?>
<?php $__env->startSection('content'); ?>

    <nav class="breadcrumb bg-white push">
        <a class="breadcrumb-item" href="<?php echo e(url('/admin')); ?>">Admin</a>
        <span class="breadcrumb-item active">Transaction History</span>
    </nav>
    <div class="block">
        <div class="block-header block-header-default">
            <h3 class="block-title">Transactions
                <small>History</small>
            </h3>
        </div>
        <?php if(sizeof($transactions)>0): ?>

                <div class="block-title">
                    <p style = "font-size:1.5em;">Your <strong>Transactions</strong></p>
                </div>
                <div class="table-responsive">
                    <table id="general-table" class="table table-striped table-vcenter">
                        <thead>
                        <tr>
                            <th class="text-center">S/No.</th>
                            <th class="text-center">Transaction ID</th>
                            <th>PNM</th>
                            <th>NGN</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i=1; ?>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><a href="<?php echo e(url('transaction/'.$transaction->transaction_id)); ?>"><?php echo e($transaction->transaction_id); ?></a></td>
                                <td><?php echo e($transaction->amount); ?></td>
                                <td><?php echo e($transaction->amount * $value); ?></td>
                                <td><?php echo e($transaction->from); ?></td>
                                <td><?php echo e($transaction->to); ?></td>
                                <td><?php echo e($transaction->type); ?></td>
                                <td><?php echo e($transaction->status); ?></td>
                                <td><?php echo e(date('d-m-Y',strtotime($transaction->created_at))); ?></td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        
                        </tfoot>
                    </table>
                </div>

        <?php else: ?>
            <div class="block">
                <div class="alert alert-warning">
                    <h2>No data to display</h2>
                    <p>Sorry, but there are no transactions to display from the database.</p>
                </div>
            </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>