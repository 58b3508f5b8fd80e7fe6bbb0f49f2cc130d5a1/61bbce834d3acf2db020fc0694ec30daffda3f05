<?php $data = session('data'); ?> <?php    $public='';    if(config('app.env') == 'production')    $public ='public'; ?> 


<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

    <div class="content">
        <h2 class="content-heading">Transaction
            <small><?php echo $title; ?></small>
        </h2>
        <div class="block">
            <?php if(isset($data['message'])): ?>
                <div class="block-content">
                    <div class="block">
                        <div class="alert alert-<?php echo e($data['alert']); ?>">
                            <p style="font-size:1.5rem; font-weight: bold;"><?php echo e($data['message']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-12 col-lg-4 col-md-6 col-xs-8" style="float: none; margin: auto;">
                <div class="block-header block-header-default">
                    <h3 class="block-title text-center"><?php echo $heading; ?></h3>
                    <div class="block-options">
                        <button type="button" class="btn-block-option">
                            <i class="si si-wrench"></i>
                        </button>
                    </div>
                </div>
                <div class="block-content">
                    <form action='<?php echo e(url("/transaction/$for/$action")); ?>' method="post" class="text-center">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <div class="form-material form-material-lg form-material-info floating">
                                    <input class="form-control form-control-lg text-center" id="amount" name="amount"
                                           type="text" required>
                                    <label for="amount"><?php if($for=='pnm'): ?><i class="si si-fire"></i><?php else: ?> &#8358; <?php endif; ?> Enter Amount</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <div class="form-material form-material-lg form-material-success floating">
                                    <input class="form-control form-control-lg text-center" id="value" name="value"
                                           type="text" readonly>
                                    <label for="value"><?php if($for=='ngn'): ?><i class="si si-fire"></i><?php else: ?> &#8358; <?php endif; ?>  Value</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <div class="form-material form-material-lg form-material-success floating">
                                    <input class="form-control form-control-lg text-center" id="pin" name="pin"
                                           type="password">
                                    <label for="pin"><i class="si si-lock"></i> Enter Pin</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <button style="overflow: hidden; position: relative; z-index: 1;" type="submit"
                                        class="btn btn-outline-secondary min-width-125 js-click-ripple-enabled"
                                        data-toggle="click-ripple"><span
                                            style="height: 125px; width: 125px; top: -44.5667px; left: 13.1667px;"
                                            class="click-ripple animate"></span>Convert
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div id="modal-transaction" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h2 class="modal-title">Wallet <i class="fa fa-angle-double-right text-danger"></i> Card</h2>
                </div>
                <div class="modal-body">
                    <form id="transaction-confirm" action="<?php echo e(url('/transactions/card')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <fieldset>
                            <legend>Confirm your transaction</legend>
                            <div class="form-group">
                                <label class="col-md-4 control-label">Wallet balance</label>
                                <div class="col-md-8">
                                    <p class="form-control-static">$50</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-4 control-label">Card balance</label>
                                <div class="col-md-8">
                                    <p class="form-control-static">$0</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-4 control-label">Transfer Amount</label>
                                <div class="col-md-8">
                                    <p class="form-control-static">$50</p>
                                </div>
                            </div>
                            <input type="hidden" id="amount" name="amount" required>
                            <div class="form-group">
                                <label class="col-md-4 control-label" for="user-settings-password">Enter
                                    Password</label>
                                <div class="col-md-8">
                                    <input type="password" id="password" name="password"
                                           class="form-control" placeholder="Your password" required>
                                </div>
                            </div>
                            <div class="form-group form-actions">
                                <div class="col-xs-12 text-right">
                                    <button type="submit" class="btn btn-sm btn-primary">Transfer</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var value = <?php echo e($value); ?>;
        var action = '<?php echo e($for); ?>';
        var amount = 0;
        function confirmTransaction() {
            var amount = $('#transfer').val();
            $('#amount').val(amount);
            $('#modal-transaction').modal('show');

        }

        setInterval(function () {
            if (action == 'pnm'){
                amount = $('#amount').val()*value;
            }
            if (action == 'ngn'){
                amount = $('#amount').val()/value;
            }
            $('#value').val(amount);
        },1000);
        <?php if(isset($data['message'])): ?>
        alert('<?php echo e($data['message']); ?>');
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>