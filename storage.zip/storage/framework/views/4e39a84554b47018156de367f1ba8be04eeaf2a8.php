<?php if((isset($results['registered']) || isset($results['unregistered'])) && ((sizeof($results['registered'])>0) ||(sizeof($results['unregistered'])>0))): ?>

    <?php if(isset($results['registered']) && sizeof($results['registered'])>0): ?>
        <div class="block-header block-header-default">
            <h3 class="block-title">Users
                <small>Viewing Registered</small>
            </h3>
        </div>
        <div class="block-content">
            <div class="table-responsive">
                <table class="table table-striped table-vcenter">
                    <thead>
                    <tr>
                        <th>S/No.</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Wallet ID</th>
                        <th>Status</th>
                        <?php if(Auth::user()->access_level>=3): ?>
                            <th class="text-center">Actions</th>
                        <?php endif; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $i=0;
                    ?>
                    <?php $__currentLoopData = $results['registered']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i++;
                         if($user->status=='pending'||$user->status =='unregistered')
                            $badge ="badge-warning";
                        elseif ($user->status=='active'||$user->status =='registered')
                            $badge ="badge-success";
                        elseif ($user->status=='blocked')
                            $badge ="badge-danger";
                        ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td class="font-w600"><?php echo e($user->first_name." ".$user->last_name); ?>

                            </td>
                            <td><a href="javascript:void(0)"><?php echo e($user->name); ?></a></td>
                            <td><a href="javascript:void(0)" class="js-tooltip-enabled" data-toggle="tooltip"
                                   data-original-title="Click me to Copy" title="Click me to copy"
                                   onclick="copyToClipboard('#wallet')"><span id="wallet"><?php echo e($user->wallet_id); ?></span>
                                </a>
                            </td>

                            <td>
                                <span class="badge <?php echo e($badge); ?>"><?php echo e($user->status); ?></span>
                            </td>
                            <?php if(Auth::user()->access_level>=3): ?>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <button data-original-title="Edit" type="button"
                                                class="btn btn-sm btn-alt-primary"
                                                data-toggle="tooltip"
                                                title="Edit <?php echo e($user->first_name); ?>"
                                                onclick="viewEditUser(<?php echo e(($user->id+9407)); ?>,'<?php echo e(''); ?>')">
                                            <i class="fa fa-pencil"></i>
                                        </button>
                                        
                                        <?php if($user->status=='blocked' || $user->status=='pending'): ?>
                                            <button data-original-title="Delete" type="button"
                                                    class="btn btn-sm btn-alt-success"
                                                    data-toggle="tooltip"
                                                    title="Approve <?php echo e($user->first_name); ?>"
                                                    onclick="verifyUser(<?php echo e(($user->id+1107)); ?>, 'approve')">
                                                <i class="fa fa-check"></i>
                                            </button>
                                        <?php endif; ?>
                                        <?php if($user->status=='active'): ?>
                                            <button data-original-title="Delete" type="button"
                                                    class="btn btn-sm btn-alt-danger"
                                                    data-toggle="tooltip"
                                                    title="Block <?php echo e($user->first_name); ?>"
                                                    onclick="verifyUser(<?php echo e(($user->id+1107)); ?>, 'block')">
                                                <i class="fa fa-times"></i>
                                            </button>
                                        <?php endif; ?>
                                        
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <?php if(isset($results['unregistered']) && sizeof($results['unregistered'])>0): ?>
        <div class="block-header block-header-default">
            <h3 class="block-title">Users
                <small>Viewing</small>
            </h3>
        </div>
        <div class="block-content">
            <div class="table-responsive">
                <table class="table table-striped table-vcenter">
                    <thead>
                    <tr>
                        <th>S/No.</th>
                        <th>Name</th>
                        <th>Wallet Address</th>
                        <th>Private Key</th>
                        <th>Account No.</th>
                        <th>Status</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $i=0;
                    ?>
                    <?php $__currentLoopData = $results['unregistered']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i++;
                         if($user->status=='pending'||$user->status =='unregistered')
                            $badge ="badge-warning";
                        elseif ($user->status=='active'||$user->status =='registered')
                            $badge ="badge-success";
                        elseif ($user->status=='blocked')
                            $badge ="badge-danger";
                        ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td class="font-w600"><?php echo e($user->first_name." ". $user->other_name ." ".$user->last_name); ?>

                            </td>

                            <td>
                                <a href="javascript:void(0)"><?php echo e($user->wallet_address); ?></a>
                            </td>
                            <td>
                                <a href="javascript:void(0)" class="js-tooltip-enabled" data-toggle="tooltip"
                                   data-original-title="Click me to Copy" title="Click me to copy"
                                   onclick="copyToClipboard('#wallet')"><span
                                            id="wallet"><?php echo e($user->private_key); ?></span></a>
                            </td>
                            <td>
                                <span><?php echo e($user->account_number); ?></span>
                            </td>
                            <td>
                                <span class="badge <?php echo e($badge); ?>"><?php echo e($user->status); ?></span>
                            </td>
                            
                                        

                                    
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
<?php else: ?>
    <div class="col-sm-12 col-lg-12">
        <div class="block p-3">
            <div class="alert alert-warning">
                <h2>No data to display</h2>
                <p>Sorry, but there are no users to display from the database.</p>
            </div>
        </div>
    </div>
<?php endif; ?>

