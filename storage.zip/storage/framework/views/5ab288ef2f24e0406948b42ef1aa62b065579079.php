<?php    $public='';    if(config('app.env') == 'production')    $public ='public'; ?> 
<?php $__env->startSection('title','API Clients'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-primary">
        <div class="panel-heading"><strong>Manage API Clients</strong></div>
        <div class="panel-body">
            <passport-clients></passport-clients>
            <passport-authorized-clients></passport-authorized-clients>
            <passport-personal-access-tokens></passport-personal-access-tokens>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-example', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>